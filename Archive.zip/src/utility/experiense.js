export const experiense = [
    {
        date: "March 12, 2020",
        title: "Envato",
        category: "Team Leader",
        description: ">Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam"

    },
    {
        date: "January 23, 2018 - 2020",
        title: "Facebook Company",
        category: "Sr. Developer",
        description: ">Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam"

    },
    {
        date: "July 23, 2016 - 2018",
        title: "Twitter Company",
        category: " Jr. Developer",
        description: ">Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam"

    },
]