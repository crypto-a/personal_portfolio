export const clientdarkitem = [
    {
        image : "assets/img/clients/1-d.jpg"
    },
    {
        image : "assets/img/clients/2-d.jpg"
    },
    {
        image : "assets/img/clients/3-d.jpg"
    },
    {
        image : "assets/img/clients/4-d.jpg"
    },
    {
        image : "assets/img/clients/5-d.jpg"
    },
    {
        image : "assets/img/clients/6-d.jpg"
    },
    {
        image : "assets/img/clients/7-d.jpg"
    },
    {
        image : "assets/img/clients/8-d.jpg"
    },
]