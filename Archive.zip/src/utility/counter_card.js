export const counter_card = [
    {
        title : "Clients",
        number : 156
    },
    {
        title : "Projects",
        number : 394
    },
    {
        title : "Countries",
        number : 37
    },

    {
        title : "Awords",
        number : 21
    }
]