export const education = [
    {
        date: "June 15, 2013 - 2016",
        title: "Master in Computer Engineering",
        category: "First Class",
        description: ">Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam"
    },
    {
        date: "June 12, 2010 - 2013",
        title: "Bachelor in Computer Engineering",
        category: "First Class",
        description: ">Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam"
    },
    {
        date: "June 1, 2009 - 2010",
        title: "Master in Computer Engineering",
        category: "(A+)",
        description: ">Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do Eiusmod Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam"
    },

]