export const services = [
    {
       image : "assets/img/service/1.svg",
       title : "Graphics Design",
       description : "Develop the Visual Identity of Your Business",
    },
    {
        image : "assets/img/service/2.svg",
        title : "Web Design",
        description : "Connect With Your Users, Not Just Your Business.",
     },
     {
        image : "assets/img/service/3.svg",
        title : "Development",
        description : "We Develop the Visual Identity of Your Business.",        
     },
     {
        image : "assets/img/service/4.svg",
        title : "Seo Friendly",
        description : "Taking your site at the top of Google's ranking.",
     },
] 