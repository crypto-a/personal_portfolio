export const newscard = [
    {
       image : "assets/img/blog/1.jpg",
       title : "Marketing",
       description: "Marketing Guide: 5 Steps to Success.",

    },
    {
        image : "assets/img/blog/2.jpg",
        title : "Business",
        description: "Best way to solve business deal issue.",
 
     },
     {
        image : "assets/img/blog/3.jpg",
        title : "Knowledge",
        description: "31 customer service stats know in 2019.",
 
     },
     {
        image : "assets/img/blog/4.jpg",
        title : "Business",
        description: "Business ideas to grow your business.",
 
     },
     {
        image : "assets/img/blog/5.jpg",
       title : "Marketing",
       description: "Marketing Guide: 5 Steps to Success.",
 
     },
     {
        image : "assets/img/blog/6.jpg",
        title : "Knowledge",
        description: "31 customer service stats know in 2019."
 
     },
]