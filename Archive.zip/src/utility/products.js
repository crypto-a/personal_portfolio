 export const products = [
    {
        title: "BonzaMart - Super market",
        description : "orem Ipsum is simply dummy text of the printing and typesetting industry.It has been the industry's standard ever since the 1500s.",
        image : "assets/img/portfolio/1.jpg",
        date : " 1, Jan - 2023",
        client : "Symphony",
        Tech: "Angular, Nodejs, Ios", 
        Type:"eCommerce",
        categories: ['graphics','templates'],
        url : "www.your-project-url.com",
        link: 
            {
                hreflink1: "D Graphics",
                hreflink2: "Templates"

            },
        
    },  

    {
        title: "ShowMania - Entertainment",
        description : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. It has been the industry's standard ever since the 1500s.",
        image : "assets/img/portfolio/2.jpg",
        date : " 15, Mar - 2022",
        client : "Martin Wilson",
        Tech: "React, Nodejs, Android", 
        Type:"Entertainment",
        categories: ['design'],
        url : "www.your-project-url.com",
        link:
            {
                hreflink1: "Web Design",
            },
        
    }, 

    {
        title: "WorldToday - Portal",
        description : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. It has been the industry's standard ever since the 1500s.",
        image : "assets/img/portfolio/3.jpg",
        date : " 5, feb - 2022",
        client : "Client : John Worrior",
        Tech: "React, Nodejs, Android", 
        Type:"News",
        categories: ['design'],
        url : "www.your-project-url.com",
        link: 
            {
                hreflink1: "Web Design",

            },
        
    }, 

    {
        title: "Doctory - Helth care",
        description : "orem Ipsum is simply dummy text of the printing and typesetting industry.It has been the industry's standard ever since the 1500s.",
        image : "assets/img/portfolio/4.jpg",
        date : " 12, Dec - 2021",
        client : "Client : Mariya Lorems",
        Tech: "PHP, Mysql", 
        Type:"Helth",
        categories: ['development'],
        url : "www.your-project-url.com",
        link: 
            {
                hreflink1: "Development",
                

            },
        
    }, 


    {
        title: "ConsultMe",
        description : "lorem Ipsum is simply dummy text of the printing and typesetting industry.It has been the industry's standard ever since the 1500s.",
        image : "assets/img/portfolio/5.jpg",
        date : " 23, Oct - 2021",
        client : "Sizuka Mitsu",
        Tech: "Android | Ios", 
        Type:" Consultancy",
        categories: ['design','templates'],
        url : "www.your-project-url.com",
        link: 
            {
                hreflink1: " Template",
                hreflink2: "Web Design"

            },
        
    }, 

    {
        title: "Shoply - The big market",
        description : "lorem Ipsum is simply dummy text of the printing and typesetting industry.It has been the industry's standard ever since the 1500s.",
        image : "assets/img/portfolio/6.jpg",
        date : " 8, may - 2020",
        client : "Babu Rao",
        Tech: "Android", 
        Type:"eCommerce",
        categories: ['graphics','development'],
        url : "www.your-project-url.com",
        link: 
            {
                hreflink1: "D Graphics",
                hreflink2: "Templates"

            },
        
    }, 

    
]

