export const about = {
    info: "I am your client Consultant having <b>8+ years</b> of experience in thisfieldprovides complete range of marketing materials and clienting solution to any industry aswellas corporate lients maintaining their reputation and increasing the client awareness usingPR & other print media & online marketing activities.",
    name: "Rob Oliver",
    age: "26 year",
    language: "English, spanish",
    phone: "+00 9876543210",
    email: "example@gmail.com",
    address: "Ruami Mello Moraes, - Salvador - MA 40352, Brazil.",
    title : "Creativity bleeds from the pen of inspiration.",
    description : "Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the text ever since the 1500s.",
    services: [
        {
            title: "Photoshop",
            persontin: "87",
            description: "Lorem Ipsum is simply dummy text of the printing."
        },
        {
            title: "HTML",
            persontin: "80",
            description: "Lorem Ipsum is simply dummy text of the printing."
        },
        {
            title: "PHP",
            persontin: "95",
            description: "Lorem Ipsum is simply dummy text of the printing."
        },
        {
            title: "Javascript",
            persontin: "70",
            description: "Lorem Ipsum is simply dummy text of the printing."
        },
    ],
}