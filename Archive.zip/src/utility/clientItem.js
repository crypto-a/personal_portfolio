export const clientitem = [
    {
        image : "assets/img/clients/1.jpg"
    },
    {
        image : "assets/img/clients/2.jpg"
    },
    {
        image : "assets/img/clients/3.jpg"
    },
    {
        image : "assets/img/clients/4.jpg"
    },
    {
        image : "assets/img/clients/5.jpg"
    },
    {
        image : "assets/img/clients/6.jpg"
    },
    {
        image : "assets/img/clients/7.jpg"
    },
    {
        image : "assets/img/clients/8.jpg"
    },
]